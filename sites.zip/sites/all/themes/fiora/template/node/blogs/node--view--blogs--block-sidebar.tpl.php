<a href="<?php echo $node_url; ?>" title="">
    <?php echo $title; ?>
</a>