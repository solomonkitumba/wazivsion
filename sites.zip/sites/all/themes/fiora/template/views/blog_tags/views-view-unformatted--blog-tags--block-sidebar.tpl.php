<div class="widget clearfix">
    <h3 class="section-sub-title">Tags</h3>
    <div class="tags">
        <?php foreach ($rows as $id => $row): ?>
            <?php print $row; ?>
        <?php endforeach; ?>
    </div>
</div><!-- end widget -->