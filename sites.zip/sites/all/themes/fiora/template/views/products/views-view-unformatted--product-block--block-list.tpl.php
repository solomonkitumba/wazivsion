<?php foreach ($rows as $id => $row): ?>
    <?php print $row; ?>
<?php endforeach; ?>