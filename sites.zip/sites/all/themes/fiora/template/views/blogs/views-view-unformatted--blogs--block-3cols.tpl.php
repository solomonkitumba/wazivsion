<div class="container">
    <div class="masonry_wrapper blog-wrapper row clearfix">
        <?php foreach ($rows as $id => $row): ?>
            <?php print $row; ?>
        <?php endforeach; ?>
    </div>
</div>