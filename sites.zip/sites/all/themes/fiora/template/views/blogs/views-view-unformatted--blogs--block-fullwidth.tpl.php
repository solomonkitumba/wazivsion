<div class="container">
    <div id="content" class="col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1">
        <?php foreach ($rows as $id => $row): ?>
            <?php print $row; ?>
        <?php endforeach; ?>
    </div>
</div>