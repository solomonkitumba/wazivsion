<div class="service-widget">
    <div class="service-list row text-center clearfix">
        <?php foreach ($rows as $id => $row): ?>
            <?php print $row; ?>
        <?php endforeach; ?>
    </div><!-- end service-list -->
</div><!-- end service-widget -->