<div class="art-gallery-item isotope-item <?php print $tag;?>">
	<div class="art-gallery-item-inner" style="margin:5px;"><a href="http://placehold.it/300x200<?php //print $image;?>" rel="lightbox[shgallery]"><img src="http://placehold.it/300x200<?php //print $image;?>"/></a></div>
</div>